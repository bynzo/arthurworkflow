# arthurworkflow

Multi-model agent workflow CLI for OpenCode. Zero native deps, zero MCP server — pure config + bash hooks.

## Install

```bash
npm install -g arthurworkflow
```

## Quick start

```bash
cd my-project
arthurworkflow init pwa      # pwa | api | default
arthurworkflow doctor        # verify setup

# Inside OpenCode:
/plan Add offline caching with service worker
# → approve plan →
/review                      # sentinel blind review
/close                       # merge + docs + lessons
/improve                     # extract patterns, update memory
```

## Architecture

```
User request
    ↓
@queen (plan) → user approval
    ↓
subagents in isolation (architect / scripter / documenter)
    ↓
@sentinel blind review (ticket + diff only)
    ↓ PASS            ↓ FAIL
merge + /close    corrective plan → loop
    ↓
@refactor → memory update → skills update
```

## Agents

| Agent       | Role                    | Tier |
|-------------|-------------------------|------|
| @queen      | Planner / orchestrator  | 1    |
| @architect  | Interfaces & structure  | 1    |
| @scripter   | Implementation & tests  | 3    |
| @sentinel   | Blind review            | 2    |
| @documenter | Docs & changelog        | 3    |
| @refactor   | Cleanup & self-improve  | 2    |

## Model tiers

Edit `opencode.jsonc` to map tiers to your available models:

```jsonc
"models": {
  "tier1": "anthropic/claude-sonnet-4-5",
  "tier2": "anthropic/claude-haiku-4-5",
  "tier3": "ollama/qwen3-coder:30b"   // local/free
}
```

## Memory

All memory lives in `.arthur/memory/` — markdown files, versioned in git:

- `architecture.md` — system design
- `conventions.md`  — code conventions
- `lessons.md`      — pitfalls & fixes (updated by @refactor)

## Templates

- `default` — blank slate
- `pwa`     — React/Vite + Workbox service worker
- `api`     — Node.js REST API

## Hooks

Installed into `.git/hooks/` on `init`:

- `post-edit.sh` — tsc + eslint after every edit
- `pre-merge.sh` — full test suite before merge
