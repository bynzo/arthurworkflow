#!/usr/bin/env bash
# pre-merge.sh — full gate before merging to main
set -euo pipefail

ROOT=$(git rev-parse --show-toplevel 2>/dev/null || echo ".")
cd "$ROOT"

echo "── pre-merge checks ──────────────────"

if [ -f "tsconfig.json" ]; then
  echo "⚙ tsc --noEmit"
  npx --yes tsc --noEmit
fi

if [ -f "package.json" ] && grep -q '"test"' package.json; then
  echo "⚙ npm test"
  npm test --if-present
fi

if [ -f ".eslintrc*" -o -f "eslint.config*" ]; then
  echo "⚙ eslint"
  npx --yes eslint . --max-warnings 0
fi

echo "✔ pre-merge passed — safe to merge"
