#!/usr/bin/env bash
# post-edit.sh — runs after every file edit
# Fails fast: any non-zero exit blocks the agent from continuing.
set -euo pipefail

ROOT=$(git rev-parse --show-toplevel 2>/dev/null || echo ".")
cd "$ROOT"

# Only run if relevant files changed
CHANGED=$(git diff --name-only 2>/dev/null || echo "")
TS_CHANGED=$(echo "$CHANGED" | grep -E '\.(ts|tsx)$' || true)
JS_CHANGED=$(echo "$CHANGED" | grep -E '\.(js|jsx|mjs)$' || true)

if [ -n "$TS_CHANGED" ] && [ -f "tsconfig.json" ]; then
  echo "⚙ tsc --noEmit"
  npx --yes tsc --noEmit
fi

if [ -n "$TS_CHANGED$JS_CHANGED" ] && [ -f ".eslintrc*" -o -f "eslint.config*" ]; then
  echo "⚙ eslint"
  npx --yes eslint . --max-warnings 0
fi

echo "✔ post-edit clean"
