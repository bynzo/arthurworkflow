# AGENTS.md — Master rules

> Table of contents, not an encyclopedia. Agents read their own .md for details.

## Agent roster

| Agent       | Role                          | Tier | Temp |
|-------------|-------------------------------|------|------|
| @queen      | Orchestrator & planner        | 1    | 0.2  |
| @architect  | Interfaces & structure        | 1    | 0.3  |
| @scripter   | Implementation & tests        | 3    | 0.5  |
| @sentinel   | Blind review (security/bugs)  | 2    | 0.1  |
| @documenter | Docs, JSDoc, changelog        | 3    | 0.7  |
| @refactor   | Cleanup & self-improvement    | 2    | 0.3  |

## Workflow

```
User request → @queen (plan) → user approval
→ subagents execute in isolation
→ @sentinel blind review (sees only ticket + diff)
→ PASS: merge + post-mortem | FAIL: feedback loop
```

## Global rules (all agents)

1. **Each task fits one session.** If it doesn't, decompose further.
2. **Context first.** Always read `.arthur/memory/` before starting.
3. **Commit incrementally.** Conventional commits, small scopes.
4. **Self-improve.** On PASS, update `.arthur/memory/` and skills as needed.
5. **Hooks are law.** post-edit.sh and pre-merge.sh must pass.

## Memory location

`.arthur/memory/` — markdown files, versioned in git.
- `architecture.md` — current system design decisions
- `conventions.md`  — project-specific code conventions
- `lessons.md`      — known pitfalls and how they were fixed
- `glossary.md`     — domain terms

## Model tiers

- **Tier 1**: Planning, architecture (expensive, slow)
- **Tier 2**: Review, refactoring (balanced)
- **Tier 3**: Implementation, docs (fast / local)

Configured per-model in `opencode.jsonc`.
