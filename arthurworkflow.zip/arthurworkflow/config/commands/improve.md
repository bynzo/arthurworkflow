# /improve

Trigger: user types `/improve [optional: focus area]`

Invoke @refactor to:
1. Analyse files changed in recent sessions (git log --since=1week)
2. Extract reusable patterns into skills
3. Propose new lint rules for recurring errors
4. Update `.arthur/memory/lessons.md` and `conventions.md`

No code behaviour changes — refactor only. Tests must pass after.
