# /plan

Trigger: user types `/plan [request]`

Invoke @queen with the user's request. Queen will:
1. Read `.arthur/memory/`
2. Scan relevant source files
3. Produce a structured task plan
4. Wait for user approval before any execution begins

If user modifies the plan, re-run planning phase with feedback.
