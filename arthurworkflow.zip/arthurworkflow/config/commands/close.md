# /close

Trigger: user types `/close`

Precondition: `/review` must have returned PASS.

Steps (in order):
1. Run pre-merge hook: `.arthur/config/hooks/pre-merge.sh`
2. Merge feature branch into main
3. Bump version (patch unless plan specified minor/major)
4. Invoke @documenter — update README + CHANGELOG
5. Invoke @refactor — extract lessons, update memory
6. Print summary: what shipped, issues encountered, token usage per agent
