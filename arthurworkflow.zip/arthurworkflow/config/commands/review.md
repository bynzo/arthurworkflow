# /review

Trigger: user types `/review`

Invoke @sentinel with:
- The original request (ticket) from the current session
- Output of `git diff main..HEAD`

Sentinel must NOT receive any agent reasoning or intermediate output.
Present PASS/FAIL result to user with issue list.

On FAIL: surface issues to @queen for a corrective plan.
