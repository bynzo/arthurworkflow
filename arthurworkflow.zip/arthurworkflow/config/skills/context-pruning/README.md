# Skill: context-pruning

Load when: token usage approaches `pruneThreshold` in `opencode.jsonc`.

## Strategy

1. **Summarise completed tasks** — replace detailed tool-call traces with
   a 3-line summary of what was done and the result.
2. **Drop read-only file contents** — if a file was only read (not written),
   remove its content from context; keep only its path.
3. **Collapse git history** — replace `git log` output with a 1-line summary.
4. **Archive to memory** — write a compact summary to `.arthur/memory/sessions/[date].md`
   before pruning so nothing is permanently lost.
5. **Retain** — current task context, open errors, active file diffs, agent instructions.

## Trigger thresholds

- Warning at 35 000 tokens
- Auto-prune at 45 000 tokens
- Hard stop + summary at 60 000 tokens
