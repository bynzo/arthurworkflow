# Skill: self-improve

Load when: @refactor runs, or after /close.

## Three levels of improvement

### 1. Project-level (always)
Update `.arthur/memory/` after every session:
- `lessons.md` — new pitfall found → cause → fix (3 lines max)
- `conventions.md` — new pattern adopted by the project
- `architecture.md` — if structure changed

### 2. Skill-level (when pattern is reusable)
If a solution is generic enough to help future projects:
- Create `.arthur/config/skills/[name]/README.md`
- Format: context → problem → solution → example

### 3. Deterministic (when a bug recurred 2+ times)
Turn the fix into a constraint:
- Write an ESLint rule or custom script
- Add it to `post-edit.sh` hook
- Document in `lessons.md`: "Now enforced by lint rule X"

## Memory file format

```md
## [YYYY-MM-DD] [topic]
**Problem**: ...
**Cause**: ...
**Fix**: ...
```
