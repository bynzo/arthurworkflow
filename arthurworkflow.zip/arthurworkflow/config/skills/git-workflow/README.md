# Skill: git-workflow

## Branch naming

```
arthur/feat-[slug]      # new feature
arthur/fix-[slug]       # bug fix
arthur/refactor-[slug]  # cleanup
arthur/docs-[slug]      # docs only
```

## Commit format (conventional commits)

```
feat(scope): short description
fix(scope): short description
test(scope): short description
docs(scope): short description
refactor(scope): short description
```

- Body: optional, explain WHY not WHAT
- Footer: `Closes #N` if applicable

## PR / merge checklist

- [ ] All tests pass (`npm test`)
- [ ] Types clean (`npx tsc --noEmit`)
- [ ] Lint passes (`npx eslint .`)
- [ ] CHANGELOG updated
- [ ] @sentinel review PASS

## Version bumping

- Fix only → patch (0.0.X)
- New feature, backward-compatible → minor (0.X.0)
- Breaking change → major (X.0.0)
