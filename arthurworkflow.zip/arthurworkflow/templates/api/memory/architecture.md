# architecture.md — API template

## Stack
- Runtime: Node.js
- Framework: (e.g. Fastify / Express / Hono)
- DB: (e.g. PostgreSQL + Drizzle / Prisma)
- Auth: (e.g. JWT / OAuth)

## Key modules
- `src/routes/`     — route handlers
- `src/services/`   — business logic
- `src/db/`         — schema + migrations
- `src/middleware/` — auth, validation, logging

## API conventions
- REST: plural nouns, versioned `/v1/`
- Errors: `{ error: string, code: string }` shape
- Pagination: `?page=1&limit=20`
