# conventions.md
<!-- Project-specific code conventions. Agents read this before every task. -->

## Naming
- Files: kebab-case
- Components: PascalCase
- Functions/variables: camelCase
- Constants: SCREAMING_SNAKE_CASE

## Structure
- One export per file (default export)
- Tests co-located: `foo.ts` → `foo.test.ts`

## Error handling
- Explicit try/catch, never silent
- User-facing errors: descriptive message, no stack traces
