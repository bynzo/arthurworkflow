# architecture.md
<!-- Describe the current system design. Update after major changes. -->

## Stack
_Fill in: language, framework, DB, hosting_

## Key modules
_List main folders and their purpose_

## External dependencies
_APIs, services, third-party SDKs_
