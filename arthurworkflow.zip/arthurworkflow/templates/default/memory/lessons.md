# lessons.md
<!-- Known pitfalls. Updated by @refactor after each session. -->
<!-- Format: ## [date] [topic] / Problem / Cause / Fix -->
