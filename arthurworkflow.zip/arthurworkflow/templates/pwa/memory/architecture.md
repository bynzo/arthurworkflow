# architecture.md — PWA template

## Stack
- Framework: (e.g. React + Vite / Next.js)
- State: (e.g. Zustand / Redux)
- Styling: (e.g. Tailwind)
- PWA: vite-plugin-pwa / Workbox

## Key modules
- `src/components/` — UI components
- `src/hooks/`      — custom React hooks
- `src/services/`   — API clients
- `public/`         — static assets + manifest.json

## PWA specifics
- Service worker: cache-first for assets, network-first for API
- Manifest: icons at 192px and 512px required
- Offline fallback: `/offline.html`
